const messages = document.getElementById("messages");
const composer = document.getElementById("composer");
const promptInput = document.getElementById("promptInput");
const sendButton = document.getElementById("sendButton");
const sessionMeta = document.getElementById("sessionMeta");
const workspaceTitle = document.getElementById("workspaceTitle");
const workspaceList = document.getElementById("workspaceList");
const workspaceMenu = document.getElementById("workspaceMenu");
const pluginPanel = document.getElementById("pluginPanel");
const pluginList = document.getElementById("pluginList");
const pluginButton = document.getElementById("pluginButton");
const closePluginPanelButton = document.getElementById("closePluginPanelButton");
const addWorkspaceButton = document.getElementById("addWorkspaceButton");
const interruptButton = document.getElementById("interruptButton");
const restartButton = document.getElementById("restartButton");

let activeAssistantBubble = null;
let activeAssistantMarkdown = "";
let isBusy = false;
let workspaceState = { activeWorkspaceId: null, activeConversation: [], workspaces: [] };
let pluginState = { activeWorkspaceId: null, plugins: [] };
let menuWorkspaceId = null;

function activeWorkspace() {
  return workspaceState.workspaces.find(
    (workspace) => workspace.id === workspaceState.activeWorkspaceId
  );
}

function scrollToBottom() {
  messages.scrollTop = messages.scrollHeight;
}

function createMessage(role, text = "") {
  const wrapper = document.createElement("article");
  wrapper.className = `message ${role}`;

  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "你" : "AI";

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  if (role === "assistant") {
    renderAssistantMarkdown(bubble, text);
  } else {
    bubble.textContent = text;
  }

  wrapper.append(avatar, bubble);
  messages.appendChild(wrapper);
  scrollToBottom();
  return bubble;
}

function renderAssistantMarkdown(element, markdown) {
  const parser = window.marked && (window.marked.parse || window.marked);
  if (typeof parser !== "function" || !window.DOMPurify) {
    element.textContent = markdown || "";
    return;
  }

  const html = parser(markdown || "");
  element.innerHTML = window.DOMPurify.sanitize(html);
}

function resetMessages(text = "你好，我可以帮你查看这个工作区、运行检查或处理开发问题。") {
  messages.textContent = "";
  createMessage("assistant", text);
  activeAssistantBubble = null;
  activeAssistantMarkdown = "";
}

function renderConversation() {
  messages.textContent = "";
  const conversation = workspaceState.activeConversation || [];
  if (conversation.length === 0) {
    const current = activeWorkspace();
    createMessage("assistant", current ? `当前工作区：${current.name}。` : "已就绪。");
    return;
  }

  for (const message of conversation) {
    createMessage(message.role === "user" ? "user" : "assistant", message.content);
  }

  activeAssistantBubble = null;
  activeAssistantMarkdown = "";
}

function setBusy(nextBusy) {
  isBusy = nextBusy;
  sendButton.disabled = nextBusy;
  promptInput.disabled = nextBusy;
  addWorkspaceButton.disabled = nextBusy;
  sessionMeta.textContent = nextBusy ? "正在思考..." : "已就绪";
}

function renderWorkspaces() {
  const current = activeWorkspace();
  workspaceTitle.textContent = current ? current.name : "AI Assistant";
  workspaceList.textContent = "";

  for (const workspace of workspaceState.workspaces) {
    const item = document.createElement("div");
    item.className = "workspace-item";
    item.title = workspace.path;
    if (workspace.id === workspaceState.activeWorkspaceId) {
      item.classList.add("active");
    }

    const switchButton = document.createElement("button");
    switchButton.type = "button";
    switchButton.className = "workspace-switch";

    const folder = document.createElement("span");
    folder.className = "workspace-folder";
    folder.textContent = workspace.pinned ? "📌" : "▱";

    const text = document.createElement("span");
    text.className = "workspace-text";

    const name = document.createElement("span");
    name.className = "workspace-name";
    name.textContent = workspace.name;

    const detail = document.createElement("span");
    detail.className = "workspace-detail";
    detail.textContent = workspace.lastMessage || workspace.path;

    text.append(name, detail);
    switchButton.append(folder, text);
    switchButton.addEventListener("click", () => switchWorkspace(workspace.id));

    const menuButton = document.createElement("button");
    menuButton.type = "button";
    menuButton.className = "workspace-menu-button";
    menuButton.textContent = "...";
    menuButton.title = "更多操作";
    menuButton.addEventListener("click", (event) => {
      event.stopPropagation();
      openWorkspaceMenu(workspace, menuButton);
    });

    item.append(switchButton, menuButton);
    workspaceList.appendChild(item);
  }
}

function pluginScopeLabel(scope) {
  return scope === "global" ? "全局" : "当前工作区";
}

function renderPlugins() {
  pluginList.textContent = "";

  for (const plugin of pluginState.plugins) {
    const card = document.createElement("article");
    card.className = "plugin-card";

    const header = document.createElement("div");
    header.className = "plugin-card-header";

    const title = document.createElement("div");
    const name = document.createElement("h3");
    name.textContent = plugin.name;
    const pkg = document.createElement("p");
    pkg.textContent = plugin.packageName;
    title.append(name, pkg);

    const description = document.createElement("p");
    description.className = "plugin-description";
    description.textContent = plugin.description;

    const permissions = document.createElement("div");
    permissions.className = "plugin-permissions";
    permissions.textContent = `权限：${plugin.permissions.join("，")}`;

    const controls = document.createElement("div");
    controls.className = "plugin-controls";
    for (const scope of plugin.scopes) {
      controls.appendChild(pluginScopeControl(plugin, scope));
    }

    header.append(title);
    card.append(header, description, permissions, controls);
    pluginList.appendChild(card);
  }
}

function pluginScopeControl(plugin, scope) {
  const state = plugin[scope];
  const wrap = document.createElement("div");
  wrap.className = "plugin-scope";

  const label = document.createElement("span");
  label.textContent = pluginScopeLabel(scope);

  const actions = document.createElement("div");
  actions.className = "plugin-scope-actions";

  if (!state) {
    const install = document.createElement("button");
    install.type = "button";
    install.textContent = "安装";
    install.addEventListener("click", () => installPlugin(plugin.id, scope));
    actions.appendChild(install);
  } else {
    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.textContent = state.enabled ? "已启用" : "已停用";
    toggle.className = state.enabled ? "enabled" : "";
    toggle.addEventListener("click", () =>
      setPluginEnabled(plugin.id, scope, !state.enabled)
    );

    const uninstall = document.createElement("button");
    uninstall.type = "button";
    uninstall.textContent = "卸载";
    uninstall.addEventListener("click", () => uninstallPlugin(plugin.id, scope));
    actions.append(toggle, uninstall);
  }

  wrap.append(label, actions);
  return wrap;
}

async function refreshPlugins() {
  pluginState = await window.assistantClient.listPlugins();
  renderPlugins();
}

async function installPlugin(pluginId, scope) {
  const result = await window.assistantClient.installPlugin(pluginId, scope);
  if (result.ok) {
    pluginState = result.state;
    renderPlugins();
  }
}

async function setPluginEnabled(pluginId, scope, enabled) {
  const result = await window.assistantClient.setPluginEnabled(pluginId, scope, enabled);
  if (result.ok) {
    pluginState = result.state;
    renderPlugins();
  }
}

async function uninstallPlugin(pluginId, scope) {
  const result = await window.assistantClient.uninstallPlugin(pluginId, scope);
  if (result.ok) {
    pluginState = result.state;
    renderPlugins();
  }
}

async function openPluginPanel() {
  await refreshPlugins();
  pluginPanel.hidden = false;
}

function closeWorkspaceMenu() {
  workspaceMenu.hidden = true;
  workspaceMenu.textContent = "";
  menuWorkspaceId = null;
}

function menuItem(label, action, disabled = false) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "workspace-menu-item";
  button.textContent = label;
  button.disabled = disabled;
  button.addEventListener("click", async () => {
    closeWorkspaceMenu();
    await action();
  });
  return button;
}

function openWorkspaceMenu(workspace, anchor) {
  if (menuWorkspaceId === workspace.id && !workspaceMenu.hidden) {
    closeWorkspaceMenu();
    return;
  }

  menuWorkspaceId = workspace.id;
  workspaceMenu.textContent = "";
  workspaceMenu.append(
    menuItem(workspace.pinned ? "取消固定工作区" : "固定工作区", () => pinWorkspace(workspace)),
    menuItem("在 Finder 中打开", () => openWorkspaceInFinder(workspace)),
    menuItem("重命名工作区", () => renameWorkspace(workspace)),
    menuItem("移除", () => removeWorkspace(workspace), workspaceState.workspaces.length <= 1)
  );

  const rect = anchor.getBoundingClientRect();
  workspaceMenu.style.left = `${Math.min(rect.left, window.innerWidth - 238)}px`;
  workspaceMenu.style.top = `${rect.bottom + 6}px`;
  workspaceMenu.hidden = false;
}

async function refreshWorkspaces() {
  workspaceState = await window.assistantClient.listWorkspaces();
  renderWorkspaces();
}

async function switchWorkspace(workspaceId) {
  if (workspaceId === workspaceState.activeWorkspaceId || isBusy) {
    return;
  }

  const result = await window.assistantClient.switchWorkspace(workspaceId);
  if (!result.ok) {
    createMessage("assistant", "当前请求还在处理中，完成后再切换工作区。");
    return;
  }

  workspaceState = result.state;
  renderWorkspaces();
  await refreshPlugins();
  renderConversation();
  promptInput.focus();
}

async function renameWorkspace(workspace) {
  const nextName = window.prompt("工作区名称", workspace.name);
  if (nextName === null || !nextName.trim()) {
    return;
  }

  const result = await window.assistantClient.renameWorkspace(workspace.id, nextName);
  if (!result.ok) {
    createMessage("assistant", "工作区名称没有保存成功。");
    return;
  }

  workspaceState = result.state;
  renderWorkspaces();
  promptInput.focus();
}

async function pinWorkspace(workspace) {
  const result = await window.assistantClient.pinWorkspace(workspace.id);
  if (!result.ok) {
    createMessage("assistant", "工作区固定状态没有保存成功。");
    return;
  }

  workspaceState = result.state;
  renderWorkspaces();
}

async function openWorkspaceInFinder(workspace) {
  const result = await window.assistantClient.openWorkspace(workspace.id);
  if (!result.ok) {
    createMessage("assistant", "没有打开这个工作区目录。");
  }
}

async function removeWorkspace(workspace) {
  if (workspaceState.workspaces.length <= 1) {
    createMessage("assistant", "至少需要保留一个工作区。");
    return;
  }

  const confirmed = window.confirm(`移除工作区“${workspace.name}”？`);
  if (!confirmed) {
    return;
  }

  const result = await window.assistantClient.removeWorkspace(workspace.id);
  if (!result.ok) {
    createMessage(
      "assistant",
      result.error === "BUSY" ? "当前请求还在处理中，完成后再移除工作区。" : "工作区没有移除成功。"
    );
    return;
  }

  const removedActive = workspace.id === workspaceState.activeWorkspaceId;
  workspaceState = result.state;
  renderWorkspaces();
  if (removedActive) {
    const current = activeWorkspace();
    resetMessages(`已切换到 ${current.name}。`);
  }
  promptInput.focus();
}

async function sendPrompt() {
  const text = promptInput.value.trim();
  if (!text || isBusy) {
    return;
  }

  createMessage("user", text);
  activeAssistantBubble = createMessage("assistant", "");
  activeAssistantMarkdown = "";
  activeAssistantBubble.classList.add("pending");
  promptInput.value = "";
  setBusy(true);

  const result = await window.assistantClient.sendMessage(text);
  if (!result.ok) {
    activeAssistantBubble.classList.remove("pending");
    renderAssistantMarkdown(
      activeAssistantBubble,
      result.error === "BUSY" ? "上一条消息还在处理中，请稍后再试。" : "消息发送失败。"
    );
    setBusy(false);
  }
}

composer.addEventListener("submit", (event) => {
  event.preventDefault();
  sendPrompt();
});

promptInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    sendPrompt();
  }
});

addWorkspaceButton.addEventListener("click", async () => {
  if (isBusy) {
    return;
  }

  const result = await window.assistantClient.addWorkspace();
  if (!result.ok) {
    return;
  }

  workspaceState = result.state;
  renderWorkspaces();
  await refreshPlugins();
  renderConversation();
  promptInput.focus();
});

pluginButton.addEventListener("click", openPluginPanel);

closePluginPanelButton.addEventListener("click", () => {
  pluginPanel.hidden = true;
});

pluginPanel.addEventListener("click", (event) => {
  if (event.target === pluginPanel) {
    pluginPanel.hidden = true;
  }
});

document.addEventListener("click", (event) => {
  if (!workspaceMenu.hidden && !workspaceMenu.contains(event.target)) {
    closeWorkspaceMenu();
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    closeWorkspaceMenu();
    pluginPanel.hidden = true;
  }
});

interruptButton.addEventListener("click", async () => {
  await window.assistantClient.interrupt();
  setBusy(false);
  promptInput.focus();
});

restartButton.addEventListener("click", async () => {
  await window.assistantClient.restart();
  await refreshWorkspaces();
  resetMessages("新会话已开始。");
  setBusy(false);
  promptInput.focus();
});

window.assistantClient.onChunk((payload) => {
  if (payload.workspaceId !== workspaceState.activeWorkspaceId) {
    return;
  }

  if (!activeAssistantBubble) {
    activeAssistantBubble = createMessage("assistant", "");
    activeAssistantMarkdown = "";
  }

  activeAssistantBubble.classList.remove("pending");
  activeAssistantMarkdown += payload.text;
  renderAssistantMarkdown(activeAssistantBubble, activeAssistantMarkdown);
  scrollToBottom();
});

window.assistantClient.onDone(async (payload) => {
  if (payload.workspaceId !== workspaceState.activeWorkspaceId) {
    return;
  }

  if (activeAssistantBubble) {
    activeAssistantBubble.classList.remove("pending");
    if (!activeAssistantMarkdown.trim() && !activeAssistantBubble.textContent.trim()) {
      renderAssistantMarkdown(activeAssistantBubble, "已完成。");
    }
  }

  activeAssistantBubble = null;
  activeAssistantMarkdown = "";
  setBusy(false);
  await refreshWorkspaces();
  renderConversation();
  promptInput.focus();
});

window.assistantClient.onStatus((status) => {
  if (status.workspaceId && status.workspaceId !== workspaceState.activeWorkspaceId) {
    return;
  }
  setBusy(status.state === "thinking");
});

window.assistantClient.onError((error) => {
  if (error.workspaceId && error.workspaceId !== workspaceState.activeWorkspaceId) {
    return;
  }

  if (!activeAssistantBubble) {
    activeAssistantBubble = createMessage("assistant", "");
  }

  activeAssistantBubble.classList.remove("pending");
  renderAssistantMarkdown(activeAssistantBubble, error.message || "本地 AI 助手暂时不可用。");
  activeAssistantBubble = null;
  activeAssistantMarkdown = "";
  setBusy(false);
});

refreshWorkspaces().then(() => {
  renderConversation();
  refreshPlugins();
});
