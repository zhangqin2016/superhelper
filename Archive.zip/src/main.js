const { app, BrowserWindow, ipcMain, dialog, shell } = require("electron");
const { spawn, spawnSync } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

const DEFAULT_COMMAND = process.env.DEFAULT_AGENT_COMMAND || "claude";
const WORKSPACE_DIR = path.resolve(__dirname, "..");

const PLUGIN_REGISTRY = [
  {
    id: "filesystem",
    name: "Filesystem",
    description: "允许 AI 读取当前工作区文件，用于代码理解和文件检查。",
    packageName: "@modelcontextprotocol/server-filesystem",
    scopes: ["workspace"],
    permissions: ["读取当前工作区目录"],
    server(workspace) {
      return {
        command: "npx",
        args: ["-y", this.packageName, workspace.path]
      };
    }
  },
  {
    id: "memory",
    name: "Memory",
    description: "给 AI 增加知识图谱记忆能力，适合跨对话保存事实。",
    packageName: "@modelcontextprotocol/server-memory",
    scopes: ["global", "workspace"],
    permissions: ["在本机保存和读取记忆数据"],
    server() {
      return {
        command: "npx",
        args: ["-y", this.packageName]
      };
    }
  },
  {
    id: "sequential-thinking",
    name: "Sequential Thinking",
    description: "提供分步推理工具，适合复杂分析、排查和规划。",
    packageName: "@modelcontextprotocol/server-sequential-thinking",
    scopes: ["global", "workspace"],
    permissions: ["本地推理工具，无外部账号要求"],
    server() {
      return {
        command: "npx",
        args: ["-y", this.packageName]
      };
    }
  },
  {
    id: "github",
    name: "GitHub",
    description: "通过 GitHub API 查询仓库、Issue、PR 和 CI 信息。",
    packageName: "@modelcontextprotocol/server-github",
    scopes: ["global", "workspace"],
    permissions: ["访问 GitHub API", "需要 GITHUB_PERSONAL_ACCESS_TOKEN 环境变量"],
    server() {
      return {
        command: "npx",
        args: ["-y", this.packageName],
        env: {
          GITHUB_PERSONAL_ACCESS_TOKEN: process.env.GITHUB_PERSONAL_ACCESS_TOKEN || ""
        }
      };
    }
  },
  {
    id: "brave-search",
    name: "Brave Search",
    description: "通过 Brave Search API 搜索公开互联网信息。",
    packageName: "@modelcontextprotocol/server-brave-search",
    scopes: ["global", "workspace"],
    permissions: ["访问 Brave Search API", "需要 BRAVE_API_KEY 环境变量"],
    server() {
      return {
        command: "npx",
        args: ["-y", this.packageName],
        env: {
          BRAVE_API_KEY: process.env.BRAVE_API_KEY || ""
        }
      };
    }
  },
  {
    id: "weather",
    name: "Weather",
    description: "通过 Open-Meteo 查询实时天气和天气预报，适合验证无密钥 MCP 插件流程。",
    packageName: "@rehmatalisayany/weather-mcp-server",
    scopes: ["global", "workspace"],
    permissions: ["访问 Open-Meteo 天气 API"],
    server() {
      return {
        command: "npx",
        args: ["-y", this.packageName]
      };
    }
  },
  {
    id: "everything",
    name: "Everything MCP",
    description: "MCP 协议测试服务，用来验证工具调用链路是否跑通。",
    packageName: "@modelcontextprotocol/server-everything",
    scopes: ["workspace"],
    permissions: ["本地测试工具"],
    server() {
      return {
        command: "npx",
        args: ["-y", this.packageName]
      };
    }
  }
];

let mainWindow;
let activeRun;
let activeWorkspaceId;
let workspaces = [];
let globalPlugins = {};

function configPath() {
  return path.join(app.getPath("userData"), "workspaces.json");
}

function workspaceName(workspacePath) {
  return path.basename(workspacePath) || workspacePath;
}

function createWorkspace(workspacePath) {
  return {
    id: crypto.randomUUID(),
    name: workspaceName(workspacePath),
    path: workspacePath,
    pinned: false,
    plugins: {},
    conversation: []
  };
}

function normalizeWorkspace(workspace) {
  workspace.id = workspace.id || crypto.randomUUID();
  workspace.name = workspace.name || workspaceName(workspace.path || WORKSPACE_DIR);
  workspace.path = workspace.path || WORKSPACE_DIR;
  workspace.pinned = Boolean(workspace.pinned);
  workspace.plugins =
    workspace.plugins && typeof workspace.plugins === "object" ? workspace.plugins : {};
  workspace.conversation = Array.isArray(workspace.conversation)
    ? workspace.conversation
    : [];
  return workspace;
}

function loadWorkspaces() {
  try {
    const raw = fs.readFileSync(configPath(), "utf8");
    const parsed = JSON.parse(raw);
    workspaces = Array.isArray(parsed.workspaces)
      ? parsed.workspaces.map(normalizeWorkspace)
      : [];
    activeWorkspaceId = parsed.activeWorkspaceId;
    globalPlugins =
      parsed.globalPlugins && typeof parsed.globalPlugins === "object"
        ? parsed.globalPlugins
        : {};
  } catch {
    workspaces = [];
    globalPlugins = {};
  }

  if (workspaces.length === 0) {
    const workspace = createWorkspace(WORKSPACE_DIR);
    workspaces = [workspace];
    activeWorkspaceId = workspace.id;
    saveWorkspaces();
  }

  if (!workspaces.some((workspace) => workspace.id === activeWorkspaceId)) {
    activeWorkspaceId = workspaces[0].id;
    saveWorkspaces();
  }
}

function saveWorkspaces() {
  fs.mkdirSync(app.getPath("userData"), { recursive: true });
  fs.writeFileSync(
    configPath(),
    JSON.stringify({ activeWorkspaceId, globalPlugins, workspaces }, null, 2)
  );
}

function workspaceSummary(workspace) {
  const lastUserMessage = [...workspace.conversation]
    .reverse()
    .find((message) => message.role === "user");

  return {
    id: workspace.id,
    name: workspace.name,
    path: workspace.path,
    pinned: Boolean(workspace.pinned),
    lastMessage: lastUserMessage ? lastUserMessage.content : "",
    messageCount: workspace.conversation.length
  };
}

function activeWorkspace() {
  return workspaces.find((workspace) => workspace.id === activeWorkspaceId) || workspaces[0];
}

function appState() {
  const current = activeWorkspace();
  return {
    activeWorkspaceId,
    activeConversation: current ? current.conversation : [],
    workspaces: [...workspaces]
      .sort((a, b) => Number(b.pinned) - Number(a.pinned))
      .map(workspaceSummary)
  };
}

function pluginById(pluginId) {
  return PLUGIN_REGISTRY.find((plugin) => plugin.id === pluginId);
}

function pluginStateFor(pluginId, scope, workspace) {
  const source = scope === "global" ? globalPlugins : workspace.plugins;
  return source[pluginId] || null;
}

function pluginMarketState() {
  const workspace = activeWorkspace();
  return {
    activeWorkspaceId: workspace.id,
    plugins: PLUGIN_REGISTRY.map((plugin) => ({
      id: plugin.id,
      name: plugin.name,
      description: plugin.description,
      packageName: plugin.packageName,
      scopes: plugin.scopes,
      permissions: plugin.permissions,
      global: pluginStateFor(plugin.id, "global", workspace),
      workspace: pluginStateFor(plugin.id, "workspace", workspace)
    }))
  };
}

function installedPluginIds(workspace) {
  const ids = new Set();
  for (const [pluginId, state] of Object.entries(globalPlugins)) {
    if (state.enabled) {
      ids.add(pluginId);
    }
  }
  for (const [pluginId, state] of Object.entries(workspace.plugins)) {
    if (state.enabled) {
      ids.add(pluginId);
    }
  }
  return [...ids];
}

function hasEnabledPlugin(workspace, pluginId) {
  return installedPluginIds(workspace).includes(pluginId);
}

function looksLikeWeatherQuestion(input) {
  return /(天气|气温|温度|下雨|降雨|预报|weather|temperature|rain|forecast)/i.test(input);
}

function weatherCodeText(code) {
  const codes = {
    0: "晴朗",
    1: "大部晴朗",
    2: "局部多云",
    3: "多云",
    45: "有雾",
    48: "雾凇",
    51: "小毛毛雨",
    53: "中等毛毛雨",
    55: "较强毛毛雨",
    61: "小雨",
    63: "中雨",
    65: "大雨",
    71: "小雪",
    73: "中雪",
    75: "大雪",
    80: "小阵雨",
    81: "中等阵雨",
    82: "强阵雨",
    95: "雷雨"
  };
  return codes[code] || "天气状况未知";
}

function extractWeatherLocation(input) {
  const normalized = input
    .replace(/[？?。！!，,]/g, " ")
    .replace(/今天|明天|现在|当前|实时|查询|帮我|看下|一下|天气|气温|温度|怎么样|如何|会不会|下雨/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  if (normalized) {
    return normalized;
  }

  return "";
}

async function fetchWeatherAnswer(input) {
  const location = extractWeatherLocation(input);
  if (!location) {
    return "请告诉我要查询哪个城市的天气。";
  }

  const geocodeUrl = new URL("https://geocoding-api.open-meteo.com/v1/search");
  geocodeUrl.searchParams.set("name", location);
  geocodeUrl.searchParams.set("count", "1");
  geocodeUrl.searchParams.set("language", "zh");
  geocodeUrl.searchParams.set("format", "json");

  const geocodeResponse = await fetch(geocodeUrl);
  if (!geocodeResponse.ok) {
    throw new Error("GEOCODING_FAILED");
  }

  const geocode = await geocodeResponse.json();
  const place = geocode.results && geocode.results[0];
  if (!place) {
    return `没有找到“${location}”的天气位置，请换一个城市名试试。`;
  }

  const weatherUrl = new URL("https://api.open-meteo.com/v1/forecast");
  weatherUrl.searchParams.set("latitude", String(place.latitude));
  weatherUrl.searchParams.set("longitude", String(place.longitude));
  weatherUrl.searchParams.set(
    "current",
    "temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m"
  );
  weatherUrl.searchParams.set(
    "daily",
    "temperature_2m_max,temperature_2m_min,precipitation_probability_max"
  );
  weatherUrl.searchParams.set("forecast_days", "2");
  weatherUrl.searchParams.set("timezone", "auto");

  const weatherResponse = await fetch(weatherUrl);
  if (!weatherResponse.ok) {
    throw new Error("WEATHER_FAILED");
  }

  const weather = await weatherResponse.json();
  const current = weather.current || {};
  const daily = weather.daily || {};
  const displayName = [place.name, place.admin1, place.country]
    .filter(Boolean)
    .join("，");

  return [
    `**${displayName} 当前天气**`,
    "",
    `- 天气：${weatherCodeText(current.weather_code)}`,
    `- 当前气温：${current.temperature_2m}${weather.current_units?.temperature_2m || "°C"}`,
    `- 湿度：${current.relative_humidity_2m}${weather.current_units?.relative_humidity_2m || "%"}`,
    `- 风速：${current.wind_speed_10m}${weather.current_units?.wind_speed_10m || "km/h"}`,
    `- 降水：${current.precipitation}${weather.current_units?.precipitation || "mm"}`,
    "",
    `今天预计：${daily.temperature_2m_min?.[0]}-${daily.temperature_2m_max?.[0]}°C，最高降水概率 ${daily.precipitation_probability_max?.[0]}%。`
  ].join("\n");
}

function writeMcpConfig(workspace) {
  const mcpServers = {};
  for (const pluginId of installedPluginIds(workspace)) {
    const plugin = pluginById(pluginId);
    if (!plugin) {
      continue;
    }

    mcpServers[plugin.id] = plugin.server(workspace);
  }

  const mcpConfigPath = path.join(app.getPath("userData"), "mcp-active.json");
  fs.writeFileSync(mcpConfigPath, JSON.stringify({ mcpServers }, null, 2));
  return mcpConfigPath;
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 960,
    height: 720,
    minWidth: 760,
    minHeight: 560,
    title: "AI Assistant",
    backgroundColor: "#f7f8fa",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, "renderer", "index.html"));
  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

function sendToRenderer(channel, payload) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send(channel, payload);
  }
}

function enabledPluginPrompt(workspace) {
  const enabled = installedPluginIds(workspace)
    .map((pluginId) => pluginById(pluginId))
    .filter(Boolean);

  if (enabled.length === 0) {
    return "";
  }

  const pluginList = enabled.map((plugin) => `- ${plugin.name}`).join("\n");
  const weatherRule = enabled.some((plugin) => plugin.id === "weather")
    ? "\n天气、气温、降雨、预报类问题必须优先使用已启用的 Weather MCP 工具，不要请求 WebSearch 权限。"
    : "";

  return `当前已启用 MCP 插件：\n${pluginList}\n请在回答用户问题时主动使用相关 MCP 工具。${weatherRule}`;
}

function buildPrompt(workspace, input) {
  const history = workspace.conversation
    .slice(-8)
    .map((message) => `${message.role === "user" ? "用户" : "助手"}：${message.content}`)
    .join("\n\n");
  const pluginPrompt = enabledPluginPrompt(workspace);

  if (!history) {
    return pluginPrompt ? `${pluginPrompt}\n\n用户：${input}` : input;
  }

  return `${pluginPrompt ? `${pluginPrompt}\n\n` : ""}以下是当前对话上下文，请基于上下文继续回答。\n\n${history}\n\n用户：${input}`;
}

function publicErrorMessage(message) {
  if (/Session ID .* already in use/i.test(message)) {
    return "刚才的请求还在收尾，请稍后再试。";
  }

  if (/command not found|ENOENT/i.test(message)) {
    return "本地 AI 助手暂时不可用，请确认服务已正确安装。";
  }

  return "处理请求时遇到问题，请稍后再试。";
}

function resolveAgentCommand() {
  if (path.isAbsolute(DEFAULT_COMMAND) && fs.existsSync(DEFAULT_COMMAND)) {
    return DEFAULT_COMMAND;
  }

  const candidates = [
    path.join(osHome(), ".local", "bin", DEFAULT_COMMAND),
    path.join(osHome(), ".npm-global", "bin", DEFAULT_COMMAND),
    `/opt/homebrew/bin/${DEFAULT_COMMAND}`,
    `/usr/local/bin/${DEFAULT_COMMAND}`,
    `/usr/bin/${DEFAULT_COMMAND}`
  ];

  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) {
      return candidate;
    }
  }

  const lookup = spawnSync(process.env.SHELL || "/bin/zsh", [
    "-lc",
    `command -v ${shellQuote(DEFAULT_COMMAND)}`
  ], {
    encoding: "utf8"
  });

  const resolved = lookup.stdout.trim();
  return resolved || DEFAULT_COMMAND;
}

function osHome() {
  return app.getPath("home");
}

function shellQuote(value) {
  return `'${String(value).replace(/'/g, "'\\''")}'`;
}

function runClaude(input) {
  if (activeRun) {
    return { ok: false, error: "BUSY" };
  }

  const workspace = activeWorkspace();
  if (looksLikeWeatherQuestion(input) && !hasEnabledPlugin(workspace, "weather")) {
    const message = "当前工作区还没有启用 Weather 插件。请在插件市场把 Weather 安装到全局或当前工作区后再查询天气。";
    workspace.conversation.push({ role: "user", content: input });
    workspace.conversation.push({ role: "assistant", content: message });
    saveWorkspaces();
    sendToRenderer("assistant:chunk", { workspaceId: workspace.id, text: message });
    sendToRenderer("assistant:done", { code: 0, workspaceId: workspace.id });
    return { ok: true };
  }

  if (looksLikeWeatherQuestion(input) && hasEnabledPlugin(workspace, "weather")) {
    sendToRenderer("assistant:status", { state: "thinking", workspaceId: workspace.id });
    workspace.conversation.push({ role: "user", content: input });
    saveWorkspaces();

    fetchWeatherAnswer(input)
      .then((message) => {
        workspace.conversation.push({ role: "assistant", content: message });
        saveWorkspaces();
        sendToRenderer("assistant:chunk", { workspaceId: workspace.id, text: message });
        sendToRenderer("assistant:done", { code: 0, workspaceId: workspace.id });
      })
      .catch(() => {
        const message = "天气服务暂时不可用，请稍后再试。";
        workspace.conversation.push({ role: "assistant", content: message });
        saveWorkspaces();
        sendToRenderer("assistant:chunk", { workspaceId: workspace.id, text: message });
        sendToRenderer("assistant:done", { code: 1, workspaceId: workspace.id });
      });

    return { ok: true };
  }

  let assistantText = "";
  let processStarted = false;
  let processFailed = false;
  const mcpConfigPath = writeMcpConfig(workspace);
  const prompt = buildPrompt(workspace, input);
  workspace.conversation.push({ role: "user", content: input });
  saveWorkspaces();

  const args = [
    "-p",
    "--session-id",
    crypto.randomUUID(),
    "--mcp-config",
    mcpConfigPath
  ];
  if (hasEnabledPlugin(workspace, "weather")) {
    args.push("--disallowedTools", "WebSearch");
  }
  args.push("--output-format", "text", prompt);

  activeRun = spawn(resolveAgentCommand(), args, {
    cwd: workspace.path,
    env: {
      ...process.env,
      PATH: [
        path.join(osHome(), ".local", "bin"),
        path.join(osHome(), ".npm-global", "bin"),
        "/opt/homebrew/bin",
        "/usr/local/bin",
        "/usr/bin",
        "/bin",
        "/usr/sbin",
        "/sbin",
        process.env.PATH || ""
      ].join(":"),
      TERM: "dumb",
      NO_COLOR: "1",
      CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: "1"
    },
    stdio: ["ignore", "pipe", "pipe"]
  });

  sendToRenderer("assistant:status", { state: "thinking", workspaceId: workspace.id });

  activeRun.on("spawn", () => {
    processStarted = true;
  });

  activeRun.stdout.on("data", (chunk) => {
    const text = chunk.toString();
    assistantText += text;
    sendToRenderer("assistant:chunk", { workspaceId: workspace.id, text });
  });

  activeRun.stderr.on("data", (chunk) => {
    const text = chunk.toString();
    assistantText += text;
    sendToRenderer("assistant:chunk", {
      workspaceId: workspace.id,
      text: publicErrorMessage(text)
    });
  });

  activeRun.on("error", (error) => {
    processFailed = true;
    const message = publicErrorMessage(error.message);
    workspace.conversation.push({ role: "assistant", content: message });
    saveWorkspaces();
    sendToRenderer("assistant:error", {
      workspaceId: workspace.id,
      message
    });
    activeRun = null;
  });

  activeRun.on("close", (code) => {
    if (processFailed || !processStarted) {
      return;
    }

    if (assistantText.trim()) {
      workspace.conversation.push({ role: "assistant", content: assistantText.trim() });
    } else if (code !== null) {
      workspace.conversation.push({
        role: "assistant",
        content: "这次没有收到有效回复，请稍后重试。"
      });
      saveWorkspaces();
    }
    sendToRenderer("assistant:done", { code, workspaceId: workspace.id });
    activeRun = null;
  });

  return { ok: true };
}

app.whenReady().then(() => {
  loadWorkspaces();
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on("window-all-closed", () => {
  if (activeRun) {
    activeRun.kill("SIGTERM");
    activeRun = null;
  }

  if (process.platform !== "darwin") {
    app.quit();
  }
});

ipcMain.handle("assistant:input", (_event, text) => {
  const prompt = String(text || "").trim();
  if (!prompt) {
    return { ok: false, error: "EMPTY" };
  }

  return runClaude(prompt);
});

ipcMain.handle("workspace:list", () => appState());

ipcMain.handle("plugins:list", () => pluginMarketState());

ipcMain.handle("plugins:install", (_event, pluginId, scope) => {
  const plugin = pluginById(pluginId);
  const workspace = activeWorkspace();
  if (!plugin || !plugin.scopes.includes(scope)) {
    return { ok: false, error: "INVALID" };
  }

  const target = scope === "global" ? globalPlugins : workspace.plugins;
  target[pluginId] = {
    enabled: true,
    installedAt: new Date().toISOString()
  };
  saveWorkspaces();
  return { ok: true, state: pluginMarketState() };
});

ipcMain.handle("plugins:set-enabled", (_event, pluginId, scope, enabled) => {
  const workspace = activeWorkspace();
  const target = scope === "global" ? globalPlugins : workspace.plugins;
  if (!target[pluginId]) {
    return { ok: false, error: "NOT_INSTALLED" };
  }

  target[pluginId].enabled = Boolean(enabled);
  saveWorkspaces();
  return { ok: true, state: pluginMarketState() };
});

ipcMain.handle("plugins:uninstall", (_event, pluginId, scope) => {
  const workspace = activeWorkspace();
  const target = scope === "global" ? globalPlugins : workspace.plugins;
  delete target[pluginId];
  saveWorkspaces();
  return { ok: true, state: pluginMarketState() };
});

ipcMain.handle("workspace:add", async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: "选择工作区目录",
    properties: ["openDirectory"]
  });

  if (result.canceled || result.filePaths.length === 0) {
    return { ok: false, canceled: true };
  }

  const selectedPath = result.filePaths[0];
  let workspace = workspaces.find((item) => item.path === selectedPath);
  if (!workspace) {
    workspace = createWorkspace(selectedPath);
    workspaces.push(workspace);
  }

  activeWorkspaceId = workspace.id;
  saveWorkspaces();
  return { ok: true, state: appState() };
});

ipcMain.handle("workspace:switch", (_event, workspaceId) => {
  if (activeRun) {
    return { ok: false, error: "BUSY" };
  }

  const workspace = workspaces.find((item) => item.id === workspaceId);
  if (!workspace) {
    return { ok: false, error: "NOT_FOUND" };
  }

  activeWorkspaceId = workspace.id;
  saveWorkspaces();
  return { ok: true, state: appState() };
});

ipcMain.handle("workspace:rename", (_event, workspaceId, nextName) => {
  const workspace = workspaces.find((item) => item.id === workspaceId);
  const name = String(nextName || "").trim();
  if (!workspace || !name) {
    return { ok: false, error: "INVALID" };
  }

  workspace.name = name.slice(0, 60);
  saveWorkspaces();
  return { ok: true, state: appState() };
});

ipcMain.handle("workspace:pin", (_event, workspaceId) => {
  const workspace = workspaces.find((item) => item.id === workspaceId);
  if (!workspace) {
    return { ok: false, error: "NOT_FOUND" };
  }

  workspace.pinned = !workspace.pinned;
  saveWorkspaces();
  return { ok: true, state: appState() };
});

ipcMain.handle("workspace:open", async (_event, workspaceId) => {
  const workspace = workspaces.find((item) => item.id === workspaceId);
  if (!workspace) {
    return { ok: false, error: "NOT_FOUND" };
  }

  const error = await shell.openPath(workspace.path);
  return error ? { ok: false, error } : { ok: true };
});

ipcMain.handle("workspace:remove", (_event, workspaceId) => {
  if (activeRun) {
    return { ok: false, error: "BUSY" };
  }

  if (workspaces.length <= 1) {
    return { ok: false, error: "LAST_WORKSPACE" };
  }

  const index = workspaces.findIndex((item) => item.id === workspaceId);
  if (index === -1) {
    return { ok: false, error: "NOT_FOUND" };
  }

  workspaces.splice(index, 1);
  if (activeWorkspaceId === workspaceId) {
    activeWorkspaceId = workspaces[Math.max(0, index - 1)].id;
  }

  saveWorkspaces();
  return { ok: true, state: appState() };
});

ipcMain.handle("assistant:interrupt", () => {
  const workspace = activeWorkspace();
  if (activeRun) {
    activeRun.kill("SIGINT");
    activeRun = null;
  }
  sendToRenderer("assistant:done", { code: null, workspaceId: workspace.id });
  return { ok: true };
});

ipcMain.handle("assistant:restart", () => {
  if (activeRun) {
    activeRun.kill("SIGTERM");
    activeRun = null;
  }

  activeWorkspace().conversation = [];
  saveWorkspaces();
  sendToRenderer("assistant:status", { state: "ready", workspaceId: activeWorkspace().id });
  return { ok: true };
});
