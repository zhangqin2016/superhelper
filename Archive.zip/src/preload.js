const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("assistantClient", {
  sendMessage: (text) => ipcRenderer.invoke("assistant:input", text),
  interrupt: () => ipcRenderer.invoke("assistant:interrupt"),
  restart: () => ipcRenderer.invoke("assistant:restart"),
  listWorkspaces: () => ipcRenderer.invoke("workspace:list"),
  addWorkspace: () => ipcRenderer.invoke("workspace:add"),
  switchWorkspace: (workspaceId) => ipcRenderer.invoke("workspace:switch", workspaceId),
  renameWorkspace: (workspaceId, name) =>
    ipcRenderer.invoke("workspace:rename", workspaceId, name),
  pinWorkspace: (workspaceId) => ipcRenderer.invoke("workspace:pin", workspaceId),
  openWorkspace: (workspaceId) => ipcRenderer.invoke("workspace:open", workspaceId),
  removeWorkspace: (workspaceId) => ipcRenderer.invoke("workspace:remove", workspaceId),
  listPlugins: () => ipcRenderer.invoke("plugins:list"),
  installPlugin: (pluginId, scope) => ipcRenderer.invoke("plugins:install", pluginId, scope),
  setPluginEnabled: (pluginId, scope, enabled) =>
    ipcRenderer.invoke("plugins:set-enabled", pluginId, scope, enabled),
  uninstallPlugin: (pluginId, scope) => ipcRenderer.invoke("plugins:uninstall", pluginId, scope),
  onChunk: (callback) => {
    ipcRenderer.on("assistant:chunk", (_event, data) => callback(data));
  },
  onStatus: (callback) => {
    ipcRenderer.on("assistant:status", (_event, data) => callback(data));
  },
  onDone: (callback) => {
    ipcRenderer.on("assistant:done", (_event, data) => callback(data));
  },
  onError: (callback) => {
    ipcRenderer.on("assistant:error", (_event, data) => callback(data));
  }
});
