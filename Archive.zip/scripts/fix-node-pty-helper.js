const fs = require("node:fs");
const path = require("node:path");

const prebuildRoot = path.join(__dirname, "..", "node_modules", "node-pty", "prebuilds");

if (!fs.existsSync(prebuildRoot)) {
  process.exit(0);
}

for (const entry of fs.readdirSync(prebuildRoot)) {
  const helper = path.join(prebuildRoot, entry, "spawn-helper");
  if (!fs.existsSync(helper)) {
    continue;
  }

  const currentMode = fs.statSync(helper).mode;
  fs.chmodSync(helper, currentMode | 0o755);
}
